document.getElementById("toggle-dark").addEventListener("click", function () {
  document.body.classList.toggle("dark-mode");
});

const form = document.getElementById("contact-form");
if (form) {
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    document.getElementById("confirmation").innerText = "Message sent! We'll get back to you soon.";
    form.reset();
  });
}